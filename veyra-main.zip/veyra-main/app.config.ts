// oxlint-disable-next-line eslint-plugin-import/no-unassigned-import -- Enable TypeScript imports in the Expo config.
import 'tsx/cjs';
import type { ConfigContext, ExpoConfig } from '@expo/config';
import withPrivateWebView from './lib/withPrivateWebView';

type ExpoPlugins = NonNullable<ExpoConfig['plugins']>;

export default ({ config }: ConfigContext): ExpoConfig => {
  const nativePlugins: ExpoPlugins =
    process.env.EXPO_PLATFORM === 'native'
      ? [['expo-dev-client', { launchMode: 'most-recent' }]]
      : [];

  return withPrivateWebView({
    ...config,
    name: 'Moncef Browser',
    slug: 'moncef-browser',
    version: process.env.BILT_APP_VERSION ?? '1.0.0',
    orientation: 'portrait',
    userInterfaceStyle: 'automatic',
    scheme: 'moncef-browser',
    runtimeVersion: {
      policy: 'appVersion',
    },
    assetBundlePatterns: ['**/*'],
    ios: {
      deploymentTarget: '16.4',
      infoPlist: {
        ITSAppUsesNonExemptEncryption: false,
      },
      supportsTablet: true,
      bundleIdentifier: process.env.BILT_IOS_BUNDLE_ID ?? 'me.bilt.veyra',
    },
    android: {
      package: process.env.BILT_ANDROID_PACKAGE ?? 'me.bilt.veyra',
    },
    web: {
      bundler: 'metro',
      // 'single' = SPA export: one index.html + client routing, so edge serving
      // needs only a single 404→index.html fallback rule.
      output: 'single',
      favicon: './public/icons/icon-192.png',
    },
    extra: {
      appStoreAppId: process.env.BILT_APP_STORE_APP_ID,
    },
    plugins: ['expo-router', 'expo-font', 'expo-video', 'expo-splash-screen', ...nativePlugins],
    experiments: {
      typedRoutes: true,
      reactCompiler: true,
    },
  });
};
