import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type Engine = 'Google' | 'Bing' | 'Yahoo' | 'DuckDuckGo' | 'Yandex' | 'AOL';
export type VideoFormat = 'mp4' | 'hls' | 'dash' | 'webm' | 'mkv';
export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  isPrivate: boolean;
  createdAt: number;
  lastActiveAt: number;
}
export interface DetectedVideo {
  id: string;
  tabId: string;
  url: string;
  title: string;
  format: VideoFormat;
  quality: string;
  sizeEstimate: string;
  detectedAt: number;
}
export interface SearchHistoryItem {
  id: string;
  query: string;
  engine: Engine;
  timestamp: number;
}
export interface Visit {
  url: string;
  title: string;
  timestamp: number;
}
export const engines: Engine[] = ['Google', 'Bing', 'Yahoo', 'DuckDuckGo', 'Yandex', 'AOL'];
export const shortcuts = [
  { id: 'google', title: 'Google', url: 'https://www.google.com' },
  { id: 'youtube', title: 'YouTube', url: 'https://www.youtube.com' },
  { id: 'facebook', title: 'Facebook', url: 'https://www.facebook.com' },
  { id: 'wikipedia', title: 'Wikipedia', url: 'https://www.wikipedia.org' },
  { id: 'yandex', title: 'Yandex', url: 'https://yandex.com' },
  { id: 'x', title: 'X', url: 'https://x.com' },
  { id: 'instagram', title: 'Instagram', url: 'https://www.instagram.com' },
  { id: 'reddit', title: 'Reddit', url: 'https://www.reddit.com' },
];
export function domain(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return 'New tab';
  }
}
const id = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const newTab = (isPrivate = false): BrowserTab => ({
  id: id(),
  title: 'New tab',
  url: '',
  isPrivate,
  createdAt: Date.now(),
  lastActiveAt: Date.now(),
});
export function resolveInput(query: string, engine: Engine): string {
  const value = query.trim();
  if (/^https?:\/\//i.test(value)) return value;
  if (/^(localhost|[\w-]+(?:\.[\w-]+)+)(:\d+)?([/?#].*)?$/i.test(value)) return `https://${value}`;
  const providers: Record<Engine, string> = {
    Google: 'https://www.google.com/search?q=',
    Bing: 'https://www.bing.com/search?q=',
    Yahoo: 'https://search.yahoo.com/search?p=',
    DuckDuckGo: 'https://duckduckgo.com/?q=',
    Yandex: 'https://yandex.com/search/?text=',
    AOL: 'https://search.aol.com/aol/search?q=',
  };
  return providers[engine] + encodeURIComponent(value);
}
interface TabHistory {
  urls: string[];
  index: number;
}
function recordHistory(history: TabHistory | undefined, url: string): TabHistory {
  if (!history) return { urls: [url], index: 0 };
  if (history.urls[history.index] === url) return history;
  if (history.urls[history.index - 1] === url) return { ...history, index: history.index - 1 };
  if (history.urls[history.index + 1] === url) return { ...history, index: history.index + 1 };
  const urls = [...history.urls.slice(0, history.index + 1), url];
  return { urls, index: urls.length - 1 };
}
interface BrowserState {
  navigationHistory: Record<string, TabHistory>;
  moveHistory: (direction: -1 | 1) => void;
  tabs: BrowserTab[];
  activeId: string;
  engine: Engine;
  history: SearchHistoryItem[];
  visits: Visit[];
  videos: Record<string, DetectedVideo[]>;
  desktop: boolean;
  badgePosition: { x: number; y: number } | null;
  hydrated: boolean;
  addTab: (isPrivate?: boolean) => string;
  selectTab: (id: string) => void;
  closeTab: (id: string) => void;
  closeAll: (isPrivate: boolean) => void;
  navigate: (url: string) => string;
  updateTab: (id: string, info: Partial<Pick<BrowserTab, 'title' | 'url'>>) => void;
  setEngine: (engine: Engine) => void;
  addSearch: (query: string) => void;
  removeSearch: (id?: string) => void;
  clearVisits: () => void;
  addVideo: (video: DetectedVideo) => void;
  clearVideos: (id: string) => void;
  setDesktop: (desktop: boolean) => void;
  setBadgePosition: (position: { x: number; y: number }) => void;
}
const firstTab = newTab();
export const useBrowserStore = create<BrowserState>()(
  persist(
    (set, get) => ({
      navigationHistory: {},
      moveHistory: (direction) =>
        set((s) => {
          const h = s.navigationHistory[s.activeId];
          if (!h) return {};
          const index = h.index + direction;
          if (index < 0 || index >= h.urls.length) return {};
          return {
            navigationHistory: { ...s.navigationHistory, [s.activeId]: { ...h, index } },
            tabs: s.tabs.map((t) =>
              t.id === s.activeId ? { ...t, url: h.urls[index], title: domain(h.urls[index]) } : t,
            ),
          };
        }),
      tabs: [firstTab],
      activeId: firstTab.id,
      engine: 'Google',
      history: [],
      visits: [],
      videos: {},
      desktop: false,
      badgePosition: null,
      hydrated: false,
      addTab: (isPrivate = false) => {
        const tab = newTab(isPrivate);
        set((s) => ({ tabs: [...s.tabs, tab], activeId: tab.id }));
        return tab.id;
      },
      selectTab: (activeId) =>
        set((s) => ({
          activeId,
          tabs: s.tabs.map((t) => (t.id === activeId ? { ...t, lastActiveAt: Date.now() } : t)),
        })),
      closeTab: (tabId) =>
        set((s) => {
          let tabs = s.tabs.filter((t) => t.id !== tabId);
          if (!tabs.length) tabs = [newTab()];
          const videos = { ...s.videos };
          delete videos[tabId];
          const navigationHistory = { ...s.navigationHistory };
          delete navigationHistory[tabId];
          return {
            tabs,
            videos,
            navigationHistory,
            activeId: s.activeId === tabId ? tabs[tabs.length - 1].id : s.activeId,
          };
        }),
      closeAll: (isPrivate) =>
        set((s) => {
          let tabs = s.tabs.filter((t) => t.isPrivate !== isPrivate);
          if (!tabs.length) tabs = [newTab()];
          const videos = Object.fromEntries(
            Object.entries(s.videos).filter(([tabId]) => tabs.some((t) => t.id === tabId)),
          );
          return {
            tabs,
            videos,
            navigationHistory: Object.fromEntries(
              Object.entries(s.navigationHistory).filter(([tabId]) =>
                tabs.some((t) => t.id === tabId),
              ),
            ),
            activeId: tabs.some((t) => t.id === s.activeId) ? s.activeId : tabs[0].id,
          };
        }),
      navigate: (url) => {
        let active = get().tabs.find((t) => t.id === get().activeId);
        if (!active) {
          const tabId = get().addTab();
          active = get().tabs.find((t) => t.id === tabId);
        }
        const tabId = active!.id;
        set((s) => ({
          tabs: s.tabs.map((t) =>
            t.id === tabId ? { ...t, url, title: domain(url), lastActiveAt: Date.now() } : t,
          ),
          videos: { ...s.videos, [tabId]: [] },
          navigationHistory: {
            ...s.navigationHistory,
            [tabId]: recordHistory(s.navigationHistory[tabId], url),
          },
        }));
        return tabId;
      },
      updateTab: (tabId, info) =>
        set((s) => {
          const tab = s.tabs.find((t) => t.id === tabId);
          const visits =
            tab && !tab.isPrivate && info.url && /^https?:/.test(info.url)
              ? [
                  { url: info.url, title: info.title || domain(info.url), timestamp: Date.now() },
                  ...s.visits.filter((v) => v.url !== info.url),
                ].slice(0, 100)
              : s.visits;
          return {
            tabs: s.tabs.map((t) => (t.id === tabId ? { ...t, ...info } : t)),
            visits,
            navigationHistory:
              info.url && /^https?:/.test(info.url)
                ? {
                    ...s.navigationHistory,
                    [tabId]: recordHistory(s.navigationHistory[tabId], info.url),
                  }
                : s.navigationHistory,
          };
        }),
      setEngine: (engine) => set({ engine }),
      addSearch: (query) =>
        set((s) =>
          s.tabs.find((t) => t.id === s.activeId)?.isPrivate
            ? {}
            : {
                history: [
                  { id: id(), query, engine: s.engine, timestamp: Date.now() },
                  ...s.history.filter((h) => h.query !== query),
                ].slice(0, 100),
              },
        ),
      removeSearch: (searchId) =>
        set((s) => ({ history: searchId ? s.history.filter((h) => h.id !== searchId) : [] })),
      clearVisits: () => set({ visits: [] }),
      addVideo: (video) =>
        set((s) => {
          if (!s.tabs.some((t) => t.id === video.tabId)) return {};
          const list = s.videos[video.tabId] || [];
          return list.some((v) => v.url === video.url)
            ? {}
            : { videos: { ...s.videos, [video.tabId]: [...list, video] } };
        }),
      clearVideos: (tabId) => set((s) => ({ videos: { ...s.videos, [tabId]: [] } })),
      setDesktop: (desktop) => set({ desktop }),
      setBadgePosition: (badgePosition) => set({ badgePosition }),
    }),
    {
      name: 'moncef-browser-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        navigationHistory: Object.fromEntries(
          Object.entries(s.navigationHistory).filter(([tabId]) =>
            s.tabs.some((t) => t.id === tabId && !t.isPrivate),
          ),
        ),
        videos: Object.fromEntries(
          Object.entries(s.videos).filter(([tabId]) =>
            s.tabs.some((t) => t.id === tabId && !t.isPrivate),
          ),
        ),
        tabs: s.tabs.filter((t) => !t.isPrivate),
        activeId: s.tabs.find((t) => t.id === s.activeId)?.isPrivate ? '' : s.activeId,
        engine: s.engine,
        history: s.history,
        visits: s.visits,
        desktop: s.desktop,
        badgePosition: s.badgePosition,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          if (!state.tabs.length) {
            const tab = newTab();
            state.tabs = [tab];
          }
          if (!state.tabs.some((t) => t.id === state.activeId)) state.activeId = state.tabs[0].id;
          state.hydrated = true;
        } else {
          useBrowserStore.setState({ hydrated: true });
        }
      },
    },
  ),
);
