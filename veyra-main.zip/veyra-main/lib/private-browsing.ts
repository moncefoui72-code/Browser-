import { Platform, UIManager } from 'react-native';
/** Never substitute shared-cookie incognito for native private profiles. */
export function supportsPrivateBrowsing(): boolean {
  if (Platform.OS === 'ios') return true;
  if (Platform.OS !== 'android') return false;
  // The native config plugin exports a capability absent from React Native's typings.
  const config = UIManager.getViewManagerConfig('RNCWebView') as
    | (ReturnType<typeof UIManager.getViewManagerConfig> & {
        Constants?: { moncefPrivateIsolation?: boolean };
        moncefPrivateIsolation?: boolean;
      })
    | undefined;
  return (
    config?.Constants?.moncefPrivateIsolation === true || config?.moncefPrivateIsolation === true
  );
}
