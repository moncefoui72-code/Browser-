import { withDangerousMod, type ConfigPlugin } from 'expo/config-plugins';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const marker = '// Moncef isolated private profiles';
const profileSource = `package com.reactnativecommunity.webview

import android.webkit.WebView
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.IdentityHashMap
import java.util.UUID

/** Separate cookie, DOM storage, and cache profiles, never the shared default cookie manager. */
object MoncefPrivateProfiles {
    private const val PREFIX = "moncef-private-"
    private val profiles = IdentityHashMap<WebView, String>()
    private var swept = false

    @JvmStatic
    fun isSupported(): Boolean = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)

    fun sweepOrphans() {
        if (!isSupported() || swept) return
        val store = ProfileStore.getInstance()
        for (name in store.allProfileNames) {
            if (name.startsWith(PREFIX)) store.deleteProfile(name)
        }
        swept = true
    }

    fun attach(view: WebView) {
        check(isSupported()) { "Private browsing requires an updated Android System WebView." }
        if (profiles.containsKey(view)) return
        sweepOrphans()
        val name = PREFIX + UUID.randomUUID().toString()
        // setProfile creates the profile; do not load it using getProfile/getOrCreateProfile,
        // as loaded Profile objects cannot be deleted within this process.
        WebViewCompat.setProfile(view, name)
        profiles[view] = name
    }

    fun releaseAfterDestroy(view: WebView) {
        val name = profiles.remove(view) ?: return
        // The WebView must be destroyed before deletion; deletion may complete asynchronously.
        check(ProfileStore.getInstance().deleteProfile(name)) { "Private profile cleanup failed." }
    }
}
`;

function replaceRequired(source: string, from: string, to: string, file: string): string {
  if (!source.includes(from))
    throw new Error(
      `Moncef private browsing integration could not patch ${file}. Review react-native-webview compatibility before building.`,
    );
  return source.replace(from, to);
}

/** Native build integration; Expo Go intentionally has no isolated-profile capability. */
const withPrivateWebView: ConfigPlugin = (config) =>
  withDangerousMod(config, [
    'android',
    async (mod) => {
      const android = path.join(
        mod.modRequest.projectRoot,
        'node_modules/react-native-webview/android',
      );
      const kotlinDir = path.join(android, 'src/main/java/com/reactnativecommunity/webview');
      const implFile = path.join(kotlinDir, 'RNCWebViewManagerImpl.kt');
      let implementation = await readFile(implFile, 'utf8');
      if (!implementation.includes(marker)) {
        implementation = replaceRequired(
          implementation,
          '        return RNCWebView(context)',
          '        MoncefPrivateProfiles.sweepOrphans()\n        return RNCWebView(context)',
          'startup cleanup',
        );
        implementation = replaceRequired(
          implementation,
          '        // Remove all previous cookies\n        CookieManager.getInstance().removeAllCookies(null);',
          `        ${marker}\n        MoncefPrivateProfiles.attach(view)`,
          'incognito cookie handling',
        );
        implementation = replaceRequired(
          implementation,
          '        webView.cleanupCallbacksAndDestroy()\n        webView.mWebChromeClient = null',
          '        webView.cleanupCallbacksAndDestroy()\n        MoncefPrivateProfiles.releaseAfterDestroy(webView)\n        webView.mWebChromeClient = null',
          'profile cleanup',
        );
        await writeFile(implFile, implementation);
      }
      await writeFile(path.join(kotlinDir, 'MoncefPrivateProfiles.kt'), profileSource);
      for (const arch of ['newarch', 'oldarch']) {
        const managerFile = path.join(
          android,
          `src/${arch}/com/reactnativecommunity/webview/RNCWebViewManager.java`,
        );
        let manager = await readFile(managerFile, 'utf8');
        if (!manager.includes('moncefPrivateIsolation')) {
          manager = replaceRequired(
            manager,
            '        return RNCWebViewManagerImpl.NAME;\n    }',
            `        return RNCWebViewManagerImpl.NAME;\n    }\n\n    @Override\n    public java.util.Map<String, Object> getExportedViewConstants() {\n        return java.util.Collections.<String, Object>singletonMap("moncefPrivateIsolation", MoncefPrivateProfiles.isSupported());\n    }`,
            `view constants (${arch})`,
          );
          await writeFile(managerFile, manager);
        }
      }
      return mod;
    },
  ]);
export default withPrivateWebView;
