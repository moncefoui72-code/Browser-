export const videoDetectorScript = `
(function() {
  if (window.__moncefDetector) return true;
  window.__moncefDetector = true;
  var seen = {}, queue = [], timer;
  function send(type, data) { window.ReactNativeWebView.postMessage(JSON.stringify({type: type, data: data})); }
  function detect(url, quality) {
    if (!url || typeof url !== 'string' || /^(blob:|data:)/i.test(url)) return;
    var match = url.match(/\\.(mp4|m3u8|mpd|webm|mkv)(?:[?#]|$)/i);
    if (!match) return;
    try { url = new URL(url, location.href).href; } catch (_) { return; }
    if (seen[url]) return; seen[url] = true;
    var format = {m3u8:'hls', mpd:'dash'}[match[1].toLowerCase()] || match[1].toLowerCase();
    var resolution = url.match(/(?:^|[\\/_-])(2160|1440|1080|720|480|360)p?(?:[\\/_-.]|$)/);
    queue.push({url:url,title:document.title || 'Video',format:format,quality:quality || (resolution ? resolution[1]+'p' : 'Auto')});
    clearTimeout(timer); timer = setTimeout(function() { send('videos',queue); queue = []; },250);
  }
  function scan() { document.querySelectorAll('video,source').forEach(function(el) { detect(el.currentSrc || el.src || el.getAttribute('src'), el.videoHeight ? el.videoHeight+'p' : undefined); }); }
  var originalFetch = window.fetch;
  window.fetch = function(input) { detect(typeof input === 'string' ? input : input && input.url); return originalFetch.apply(this,arguments).then(function(res) { detect(res.url); return res; }); };
  var open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method,url) { detect(url); return open.apply(this,arguments); };
  try { new PerformanceObserver(function(list) { list.getEntries().forEach(function(e) { detect(e.name); }); }).observe({entryTypes:['resource']}); } catch (_) {}
  performance.getEntriesByType('resource').forEach(function(e) { detect(e.name); });
  new MutationObserver(scan).observe(document,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
  document.addEventListener('loadedmetadata',scan,true);
  var lastY = 0, lastSent = 0;
  window.addEventListener('scroll',function() { if (Date.now()-lastSent < 150) return; var y = window.scrollY; send('scroll',{hidden:y > lastY && y > 80}); lastY=y; lastSent=Date.now(); },{passive:true});
  scan(); return true;
})(); true;
`;
