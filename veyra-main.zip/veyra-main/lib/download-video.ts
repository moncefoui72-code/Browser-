import { File, Paths } from 'expo-file-system';
import { Platform } from 'react-native';
import type { DetectedVideo } from './browser-store';
export async function downloadVideo(video: DetectedVideo, referer: string): Promise<string> {
  if (video.format === 'hls' || video.format === 'dash')
    throw new Error('Stream downloads are not supported yet. Watch this stream instead.');
  if (Platform.OS === 'web') {
    const response = await fetch(video.url);
    if (!response.ok) throw new Error('Couldn’t download this video. Try again.');
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `moncef-video.${video.format}`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'Video downloaded';
  }
  const destination = new File(Paths.document, `moncef-${Date.now()}.${video.format}`);
  try {
    await File.downloadFileAsync(video.url, destination, { headers: { Referer: referer } });
    return `Saved as ${destination.name}`;
  } catch {
    if (destination.exists) destination.delete();
    throw new Error('Couldn’t download this video. It may require access from the original page.');
  }
}
