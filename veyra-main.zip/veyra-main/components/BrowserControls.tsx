import { Button } from 'heroui-native';
import { View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { Copy } from 'lucide-react-native';
import { router } from 'expo-router';
import { AppText } from './AppText';
import { colors } from '@/lib/theme';
import { useBrowserStore } from '@/lib/browser-store';
export function IconButton({
  icon: Icon,
  onPress,
  label,
  disabled = false,
  primary = false,
}: {
  icon: LucideIcon;
  onPress: () => void;
  label: string;
  disabled?: boolean;
  primary?: boolean;
}) {
  return (
    <Button
      isIconOnly
      variant={primary ? 'primary' : 'ghost'}
      isDisabled={disabled}
      onPress={onPress}
      accessibilityLabel={label}
      className="rounded-full"
    >
      <Icon size={23} strokeWidth={1.9} color={disabled ? colors.muted : colors.foreground} />
    </Button>
  );
}
export function TabsButton() {
  const count = useBrowserStore((s) => s.tabs.length);
  return (
    <Button
      isIconOnly
      variant="ghost"
      onPress={() => router.push('/tabs')}
      accessibilityLabel={`${count} open ${count === 1 ? 'tab' : 'tabs'}`}
      className="rounded-full"
    >
      <View>
        <Copy size={25} color={colors.foreground} strokeWidth={1.9} />
        <View className="bg-accent absolute -top-2 -right-2 min-w-5 items-center rounded-full px-1">
          <AppText className="text-xs" weight="semibold">
            {count}
          </AppText>
        </View>
      </View>
    </Button>
  );
}
