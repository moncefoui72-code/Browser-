import { Dialog, Button } from 'heroui-native';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import { AppText } from './AppText';
import type { ReactNode } from 'react';
export function BrowserDialog({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const { height } = useWindowDimensions();
  return (
    <Dialog
      isOpen={open}
      onOpenChange={(value) => {
        if (!value) onClose();
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay />
        <Dialog.Content className="bg-surface mx-4 rounded-3xl p-5">
          <View className="mb-4 flex-row items-center justify-between">
            <Dialog.Title>
              <AppText weight="semibold" className="text-xl">
                {title}
              </AppText>
            </Dialog.Title>
            <Dialog.Close accessibilityLabel="Close" />
          </View>
          <ScrollView
            style={{ maxHeight: Math.max(180, height * 0.55) }}
            keyboardShouldPersistTaps="handled"
          >
            {children}
          </ScrollView>
          <View className="mt-4">
            {footer || (
              <Button variant="secondary" onPress={onClose}>
                <Button.Label>Done</Button.Label>
              </Button>
            )}
          </View>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog>
  );
}
