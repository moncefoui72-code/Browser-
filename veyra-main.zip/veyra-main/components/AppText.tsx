import { Text, type TextProps } from 'react-native';
import { cn } from '@/lib/utils';
export function AppText({
  className,
  weight = 'regular',
  style,
  ...props
}: TextProps & { className?: string; weight?: 'regular' | 'medium' | 'semibold' | 'bold' }) {
  const families = {
    regular: 'Inter_400Regular',
    medium: 'Inter_500Medium',
    semibold: 'Inter_600SemiBold',
    bold: 'Inter_700Bold',
  };
  return (
    <Text
      {...props}
      className={cn('text-foreground text-base', className)}
      style={[{ fontFamily: families[weight] }, style]}
    />
  );
}
