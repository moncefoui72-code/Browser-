import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PanResponder, View } from 'react-native';
import { Button } from 'heroui-native';
import { Video } from 'lucide-react-native';
import { AppText } from './AppText';
import { useBrowserStore } from '@/lib/browser-store';
import { colors } from '@/lib/theme';
export function FloatingVideoBadge({
  count,
  width,
  height,
  onPress,
}: {
  count: number;
  width: number;
  height: number;
  onPress: () => void;
}) {
  const saved = useBrowserStore((s) => s.badgePosition);
  const [position, setPosition] = useState(saved || { x: width - 144, y: height * 0.65 });
  const origin = useRef(position);
  const current = useRef(position);
  const clamp = useCallback(
    (x: number, y: number) => ({
      x: Math.max(8, Math.min(x, Math.max(8, width - 140))),
      y: Math.max(8, Math.min(y, Math.max(8, height - 60))),
    }),
    [width, height],
  );
  useEffect(() => {
    const next = {
      x: Math.max(8, Math.min(current.current.x, width - 140)),
      y: Math.max(8, Math.min(current.current.y, height - 60)),
    };
    current.current = next;
    setPosition(next);
  }, [width, height]);
  const pan = useMemo(
    () =>
      // eslint-disable-next-line react/refs -- PanResponder stores event handlers; current/origin refs are only read in later gesture callbacks.
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) + Math.abs(g.dy) > 8,
        onPanResponderGrant: () => {
          origin.current = current.current;
        },
        onPanResponderMove: (_, g) => {
          const next = clamp(origin.current.x + g.dx, origin.current.y + g.dy);
          current.current = next;
          setPosition(next);
        },
        onPanResponderRelease: () => useBrowserStore.getState().setBadgePosition(current.current),
      }),
    [clamp, setPosition, current, origin],
  );
  return (
    <View
      {...pan.panHandlers}
      style={{
        position: 'absolute',
        left: position.x,
        top: position.y,
        shadowColor: colors.black,
        shadowOpacity: 0.25,
        shadowOffset: { width: 0, height: 4 },
        shadowRadius: 10,
        elevation: 6,
      }}
    >
      <Button
        variant="secondary"
        onPress={onPress}
        className="border-border rounded-full border px-4"
        accessibilityLabel={`${count} detected ${count === 1 ? 'video' : 'videos'}`}
      >
        <Video color={colors.amber} size={21} />
        <AppText className="text-sm" weight="semibold">
          {count} {count === 1 ? 'video' : 'videos'}
        </AppText>
      </Button>
    </View>
  );
}
