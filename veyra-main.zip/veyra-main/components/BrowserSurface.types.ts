import type { BrowserTab } from '@/lib/browser-store';
export interface BrowserHandle {
  back: () => void;
  forward: () => void;
  reload: () => void;
  stop: () => void;
}
export interface BrowserSurfaceProps {
  tab: BrowserTab;
  desktop: boolean;
  active: boolean;
  onState: (state: { canGoBack: boolean; canGoForward: boolean; loading: boolean }) => void;
  onProgress: (progress: number) => void;
  onScroll: (hidden: boolean) => void;
}
