import { useImperativeHandle, useState, type Ref } from 'react';
import { Linking, View } from 'react-native';
import { Button } from 'heroui-native';
import { ExternalLink, Smartphone, ShieldCheck } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { AppText } from './AppText';
import { colors } from '@/lib/theme';
import { domain } from '@/lib/browser-store';
import type { BrowserHandle, BrowserSurfaceProps } from './BrowserSurface.types';
export function BrowserSurface({
  tab,
  active,
  ref,
}: BrowserSurfaceProps & { ref?: Ref<BrowserHandle> }) {
  const [failed, setFailed] = useState(false);
  useImperativeHandle(
    ref,
    () => ({ back: () => {}, forward: () => {}, reload: () => setFailed(false), stop: () => {} }),
    [],
  );
  return (
    <View
      className="flex-1 items-center justify-center gap-6 px-8"
      style={{ display: active ? 'flex' : 'none' }}
    >
      <Smartphone size={48} strokeWidth={1.4} color={colors.link} />
      <View className="items-center gap-3">
        <AppText className="text-center text-xl" weight="semibold">
          Ready to browse on Android
        </AppText>
        <AppText className="text-muted text-center leading-6">
          In-app browsing and video detection run in the native app. You can open {domain(tab.url)}{' '}
          in your web browser now.
        </AppText>
      </View>
      <Button
        onPress={() => {
          setFailed(false);
          void Linking.openURL(tab.url).catch(() => {
            setFailed(true);
            void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          });
        }}
      >
        <ExternalLink size={18} color={colors.foreground} />
        <Button.Label>Open website</Button.Label>
      </Button>
      {failed ? (
        <AppText className="text-danger text-center">Couldn’t open this page. Try again.</AppText>
      ) : null}
      {tab.isPrivate ? (
        <View className="flex-row gap-2">
          <ShieldCheck color={colors.muted} size={16} />
          <AppText className="text-muted text-xs">
            External pages use your browser’s privacy settings.
          </AppText>
        </View>
      ) : null}
    </View>
  );
}
