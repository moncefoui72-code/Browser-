import { useState } from 'react';
import { View } from 'react-native';
import { Button } from 'heroui-native';
import { router } from 'expo-router';
import { EyeOff, Layers, Trash2, ShieldCheck } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { BrowserDialog } from './BrowserDialog';
import { AppText } from './AppText';
import { useBrowserStore } from '@/lib/browser-store';
import { colors } from '@/lib/theme';
export function BrowserMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [confirm, setConfirm] = useState(false);
  const [privacy, setPrivacy] = useState(false);
  const addTab = useBrowserStore((s) => s.addTab);
  return (
    <>
      <BrowserDialog open={open} onClose={onClose} title="Browser menu">
        <View className="gap-2">
          <Button
            variant="ghost"
            className="justify-start"
            onPress={() => {
              addTab(true);
              onClose();
              router.push('/search');
              void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }}
          >
            <EyeOff color={colors.link} size={21} />
            <Button.Label>New private tab</Button.Label>
          </Button>
          <Button
            variant="ghost"
            className="justify-start"
            onPress={() => {
              onClose();
              router.push('/tabs');
            }}
          >
            <Layers color={colors.link} size={21} />
            <Button.Label>Manage tabs</Button.Label>
          </Button>
          <Button
            variant="ghost"
            className="justify-start"
            onPress={() => {
              onClose();
              setPrivacy(true);
            }}
          >
            <ShieldCheck color={colors.link} size={21} />
            <Button.Label>Privacy</Button.Label>
          </Button>
          <Button
            variant="ghost"
            className="justify-start"
            onPress={() => {
              onClose();
              setConfirm(true);
            }}
          >
            <Trash2 color={colors.danger} size={21} />
            <Button.Label>Clear browsing history</Button.Label>
          </Button>
        </View>
      </BrowserDialog>
      <BrowserDialog
        open={privacy}
        onClose={() => setPrivacy(false)}
        title="Your browsing, your device"
      >
        <AppText className="text-muted leading-6">
          Tabs, search history, and preferences stay on this device. Private tabs are not saved and
          do not add browsing or search history. Private cookie and session isolation requires a
          supported native build. Private pages are blocked when isolation is unavailable. Websites
          and your network can still see your activity.
        </AppText>
      </BrowserDialog>
      <BrowserDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Clear history?"
        footer={
          <Button
            variant="danger"
            onPress={() => {
              useBrowserStore.getState().removeSearch();
              useBrowserStore.getState().clearVisits();
              setConfirm(false);
              void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }}
          >
            <Button.Label>Clear history</Button.Label>
          </Button>
        }
      >
        <AppText className="text-muted">
          Remove recent searches and visited pages. Open tabs will stay.
        </AppText>
      </BrowserDialog>
    </>
  );
}
