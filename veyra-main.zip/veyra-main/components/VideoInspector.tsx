import { useState } from 'react';
import { View } from 'react-native';
import { BottomSheet, Button, Spinner } from 'heroui-native';
import { BottomSheetFlatList } from '@gorhom/bottom-sheet';
import { router } from 'expo-router';
import { Video, Play, Download, RefreshCw } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { AppText } from './AppText';
import { colors } from '@/lib/theme';
import { useBrowserStore, type DetectedVideo, domain } from '@/lib/browser-store';
import { downloadVideo } from '@/lib/download-video';
export function VideoInspector({
  open,
  onClose,
  tabId,
  onRescan,
}: {
  open: boolean;
  onClose: () => void;
  tabId: string;
  onRescan: () => void;
}) {
  const allVideos = useBrowserStore((s) => s.videos);
  const tabs = useBrowserStore((s) => s.tabs);
  const videos = allVideos[tabId] || [];
  const referer = tabs.find((t) => t.id === tabId)?.url || '';
  const isPrivate = !!tabs.find((t) => t.id === tabId)?.isPrivate;
  const [pending, setPending] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [failed, setFailed] = useState(false);
  const [lastVideo, setLastVideo] = useState<DetectedVideo | null>(null);
  const download = async (video: DetectedVideo) => {
    setLastVideo(video);
    setPending(video.id);
    setMessage('');
    setFailed(false);
    try {
      setMessage(await downloadVideo(video, referer));
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      setFailed(true);
      setMessage(
        error instanceof Error ? error.message : 'Couldn’t download this video. Try again.',
      );
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setPending(null);
    }
  };
  return (
    <BottomSheet
      isOpen={open}
      onOpenChange={(value) => {
        if (!value) onClose();
      }}
    >
      <BottomSheet.Portal>
        <BottomSheet.Overlay />
        <BottomSheet.Content
          snapPoints={['65%', '90%']}
          enableDynamicSizing={false}
          enableOverDrag={false}
          contentContainerClassName="h-full"
          backgroundClassName="bg-surface"
        >
          <View className="mb-4 flex-row items-center justify-between">
            <BottomSheet.Title>
              <AppText className="text-xl" weight="semibold">
                Detected videos
              </AppText>
            </BottomSheet.Title>
            <BottomSheet.Close accessibilityLabel="Close videos" />
          </View>
          <BottomSheetFlatList
            data={videos}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ gap: 16, paddingBottom: 12 }}
            style={{ flex: 1 }}
            ListEmptyComponent={
              <View className="items-center gap-4 py-8">
                <Video color={colors.amber} size={34} />
                <AppText className="text-muted text-center">
                  Playable video links will appear here.
                </AppText>
                <Button
                  variant="secondary"
                  onPress={() => {
                    onRescan();
                    onClose();
                  }}
                >
                  <RefreshCw color={colors.foreground} size={18} />
                  <Button.Label>Reload page</Button.Label>
                </Button>
              </View>
            }
            renderItem={({ item }) => (
              <View className="border-border border-b pb-4">
                <View className="flex-row items-center gap-3">
                  <Video size={24} color={colors.amber} />
                  <View className="flex-1">
                    <AppText weight="medium" numberOfLines={2}>
                      {item.title}
                    </AppText>
                    <AppText className="text-muted mt-1 text-xs" numberOfLines={1}>
                      {item.format.toUpperCase()} · {item.quality} · {domain(item.url)}
                    </AppText>
                  </View>
                </View>
                <View className="mt-4 flex-row gap-3">
                  <Button
                    className="flex-1"
                    onPress={() => {
                      onClose();
                      router.push({
                        pathname: '/player',
                        params: {
                          url: item.url,
                          title: item.title,
                          format: item.format,
                          quality: item.quality,
                          tabId,
                          referer,
                        },
                      });
                    }}
                  >
                    <Play size={16} color={colors.foreground} />
                    <Button.Label>Watch</Button.Label>
                  </Button>
                  <Button
                    variant="secondary"
                    className="flex-1"
                    isDisabled={
                      pending !== null ||
                      isPrivate ||
                      item.format === 'hls' ||
                      item.format === 'dash'
                    }
                    onPress={() => {
                      void download(item);
                    }}
                  >
                    {pending === item.id ? (
                      <Spinner size="sm" />
                    ) : (
                      <Download color={colors.foreground} size={16} />
                    )}
                    <Button.Label>Download</Button.Label>
                  </Button>
                </View>
              </View>
            )}
          />
          <View className="border-border pb-safe-or-4 border-t pt-3">
            {message ? (
              <View className="mb-3 gap-2">
                <AppText className={failed ? 'text-danger text-sm' : 'text-link text-sm'}>
                  {message}
                </AppText>
                {failed && lastVideo ? (
                  <Button
                    variant="secondary"
                    isDisabled={pending !== null}
                    onPress={() => {
                      void download(lastVideo);
                    }}
                  >
                    <Button.Label>Try again</Button.Label>
                  </Button>
                ) : null}
              </View>
            ) : null}
            <AppText className="text-muted text-xs">
              {isPrivate
                ? 'Downloads are unavailable in private tabs.'
                : 'Direct video files can be downloaded. Stream playlists are watch-only.'}
            </AppText>
            <Button variant="secondary" className="mt-3" onPress={onClose}>
              <Button.Label>Done</Button.Label>
            </Button>
          </View>
        </BottomSheet.Content>
      </BottomSheet.Portal>
    </BottomSheet>
  );
}
