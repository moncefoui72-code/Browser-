import { View, Text } from 'react-native';
import Svg, { Path, Circle } from 'react-native-svg';
import { Instagram } from 'lucide-react-native';
import { colors } from '@/lib/theme';
export function MoncefLogo({ size = 54 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 64 64">
      <Path
        d="M5 52V12Q5 2 13 7L32 25 49 8Q59 0 59 12V51Q59 62 50 59Q44 57 44 51V31L18 57Q5 68 5 52Z"
        fill={colors.googleBlue}
      />
      <Path d="M5 12Q5 2 13 7L32 25 21 35 5 20Z" fill={colors.link} />
      <Path d="M5 52L31 28 42 39 18 57Q5 68 5 52Z" fill={colors.darkAccent} />
      <Path d="M32 25L49 8Q59 0 59 12V20L44 33Z" fill={colors.accent} />
    </Svg>
  );
}
export function GoogleMark({ size = 28 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 48 48">
      <Path
        fill={colors.googleYellow}
        d="M43.6 20H24v8h11.3c-1.6 4.7-6 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C33.9 6 29.2 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.7-.4-4Z"
      />
      <Path
        fill={colors.googleRed}
        d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3 0 5.7 1.1 7.8 2.9l5.7-5.7C33.9 6 29.2 4 24 4c-7.7 0-14.4 4.3-17.7 10.7Z"
      />
      <Path
        fill={colors.googleGreen}
        d="M24 44c5.1 0 9.8-2 13.4-5.2l-6.2-5.2A11.9 11.9 0 0 1 12.8 29l-6.6 5.1A20 20 0 0 0 24 44Z"
      />
      <Path
        fill={colors.googleBlue}
        d="M43.6 20H24v8h11.3a12 12 0 0 1-4.1 5.6l6.2 5.2C41.6 35.1 44 29.9 44 24c0-1.3-.1-2.7-.4-4Z"
      />
    </Svg>
  );
}
export function SiteIcon({ name, size = 42 }: { name: string; size?: number }) {
  const background: Record<string, string> = {
    google: colors.white,
    youtube: colors.youtube,
    facebook: colors.facebook,
    wikipedia: colors.white,
    yandex: colors.yandex,
    x: colors.black,
    instagram: colors.instagram,
    reddit: colors.reddit,
  };
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.3,
        backgroundColor: background[name] || colors.accent,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {name === 'google' ? (
        <GoogleMark size={size * 0.84} />
      ) : name === 'youtube' ? (
        <Svg width={size * 0.72} height={size * 0.6} viewBox="0 0 40 30">
          <Path
            d="M4 2Q20-1 36 2Q40 3 40 15Q40 27 36 28Q20 31 4 28Q0 27 0 15Q0 3 4 2Z"
            fill={colors.white}
          />
          <Path d="m16 8 12 7-12 7Z" fill={colors.youtube} />
        </Svg>
      ) : name === 'instagram' ? (
        <Instagram color={colors.white} size={size * 0.64} strokeWidth={2} />
      ) : name === 'reddit' ? (
        <Svg width={size * 0.75} height={size * 0.75} viewBox="0 0 40 40">
          <Path d="m21 13 3-9 9 2" stroke={colors.white} strokeWidth={2} fill="none" />
          <Circle cx="34" cy="6" r="3" fill="none" stroke={colors.white} strokeWidth={2} />
          <Path
            d="M7 20Q1 13 7 13Q10 13 12 16M33 20Q39 13 33 13Q30 13 28 16"
            fill="none"
            stroke={colors.white}
            strokeWidth={2}
          />
          <Path
            d="M5 24C5 11 35 11 35 24C35 37 5 37 5 24Z"
            fill="none"
            stroke={colors.white}
            strokeWidth={2}
          />
          <Circle cx="14" cy="23" r="2" fill={colors.white} />
          <Circle cx="26" cy="23" r="2" fill={colors.white} />
          <Path d="M14 29q6 5 12 0" stroke={colors.white} strokeWidth={2} fill="none" />
        </Svg>
      ) : (
        <Text
          style={{
            color: name === 'wikipedia' ? colors.background : colors.white,
            fontSize: size * (name === 'facebook' ? 0.96 : 0.78),
            fontWeight: '700',
            lineHeight: size,
            fontFamily: name === 'wikipedia' ? 'serif' : undefined,
          }}
        >
          {({ facebook: 'f', wikipedia: 'W', yandex: 'Y', x: 'X' } as Record<string, string>)[
            name
          ] || name.slice(0, 1).toUpperCase()}
        </Text>
      )}
    </View>
  );
}
