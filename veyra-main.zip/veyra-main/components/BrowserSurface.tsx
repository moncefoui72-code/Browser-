import { useEffect, useImperativeHandle, useRef, useState, type Ref } from 'react';
import { View, Linking } from 'react-native';
import { Button, Spinner } from 'heroui-native';
import RNWebView from 'react-native-webview';
import { AlertCircle } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { WebView } from '@/components/ui/primitives/WebView';
import { AppText } from './AppText';
import { useBrowserStore, type VideoFormat } from '@/lib/browser-store';
import { videoDetectorScript } from '@/lib/video-detector';
import { colors } from '@/lib/theme';
import { supportsPrivateBrowsing } from '@/lib/private-browsing';
import type { BrowserHandle, BrowserSurfaceProps } from './BrowserSurface.types';
function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object';
}
function isVideoFormat(value: unknown): value is VideoFormat {
  return (
    value === 'mp4' || value === 'hls' || value === 'dash' || value === 'webm' || value === 'mkv'
  );
}
const desktopAgent =
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
export function BrowserSurface({
  tab,
  desktop,
  active,
  onState,
  onProgress,
  onScroll,
  ref,
}: BrowserSurfaceProps & { ref?: Ref<BrowserHandle> }) {
  const view = useRef<RNWebView>(null);
  const currentUrl = useRef(tab.url);
  const [sourceUrl, setSourceUrl] = useState(tab.url);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (active && tab.isPrivate && !supportsPrivateBrowsing())
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    if (!active)
      view.current?.injectJavaScript(
        "document.querySelectorAll('video,audio').forEach(function(el){el.pause();});true;",
      );
  }, [active, tab.isPrivate]);
  useEffect(() => {
    if (tab.url !== currentUrl.current) {
      currentUrl.current = tab.url;
      setSourceUrl(tab.url);
      setError(false);
    }
  }, [tab.url]);
  useImperativeHandle(
    ref,
    () => ({
      back: () => view.current?.goBack(),
      forward: () => view.current?.goForward(),
      reload: () => {
        setError(false);
        view.current?.reload();
      },
      stop: () => view.current?.stopLoading(),
    }),
    [],
  );
  const fail = () => {
    setError(true);
    setLoading(false);
    onProgress(1);
    onState({ canGoBack: false, canGoForward: false, loading: false });
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
  };
  if (tab.isPrivate && !supportsPrivateBrowsing())
    return (
      <View
        style={{ flex: 1, display: active ? 'flex' : 'none' }}
        className="bg-background items-center justify-center gap-4 px-8"
      >
        <AlertCircle size={34} color={colors.amber} />
        <AppText className="text-center text-xl" weight="semibold">
          Private browsing is unavailable
        </AppText>
        <AppText className="text-muted text-center leading-6">
          Private sessions need the installed Moncef app and a compatible Android System WebView. No
          page has been loaded.
        </AppText>
        <Button
          variant="secondary"
          onPress={() => {
            useBrowserStore.getState().closeTab(tab.id);
          }}
        >
          <Button.Label>Close private tab</Button.Label>
        </Button>
      </View>
    );
  return (
    <View style={{ flex: 1, display: active ? 'flex' : 'none' }}>
      <WebView
        ref={view}
        source={{ uri: sourceUrl }}
        style={{ flex: 1, backgroundColor: colors.white }}
        userAgent={desktop ? desktopAgent : undefined}
        key={`${tab.id}-${desktop}`}
        incognito={tab.isPrivate}
        cacheEnabled={!tab.isPrivate}
        sharedCookiesEnabled={false}
        thirdPartyCookiesEnabled={!tab.isPrivate}
        domStorageEnabled
        javaScriptEnabled
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction
        setSupportMultipleWindows={false}
        injectedJavaScriptBeforeContentLoaded={videoDetectorScript}
        injectedJavaScript={videoDetectorScript}
        onLoadStart={() => {
          setLoading(true);
          setError(false);
          useBrowserStore.getState().clearVideos(tab.id);
        }}
        onLoadEnd={() => setLoading(false)}
        onError={fail}
        onHttpError={(event) => {
          if (event.nativeEvent.statusCode >= 400 && event.nativeEvent.url === currentUrl.current)
            fail();
        }}
        onLoadProgress={(event) => {
          if (active) onProgress(event.nativeEvent.progress);
        }}
        onNavigationStateChange={(state) => {
          currentUrl.current = state.url;
          if (/^https?:/.test(state.url))
            useBrowserStore
              .getState()
              .updateTab(tab.id, { url: state.url, title: state.title || tab.title });
          if (active)
            onState({
              canGoBack: state.canGoBack,
              canGoForward: state.canGoForward,
              loading: state.loading,
            });
        }}
        onShouldStartLoadWithRequest={(request) => {
          if (/^(https?:|about:|blob:|data:)/i.test(request.url)) return true;
          void Linking.openURL(request.url).catch(fail);
          return false;
        }}
        onMessage={(event) => {
          try {
            const message: { type?: string; data?: unknown } = JSON.parse(event.nativeEvent.data);
            if (
              message.type === 'scroll' &&
              active &&
              message.data &&
              typeof message.data === 'object' &&
              'hidden' in message.data
            )
              onScroll(Boolean(message.data.hidden));
            if (message.type === 'videos' && Array.isArray(message.data))
              for (const value of message.data as unknown[]) {
                if (!isRecord(value)) continue;
                const video = value;
                if (
                  typeof video.url !== 'string' ||
                  !/^https?:\/\//i.test(video.url) ||
                  !isVideoFormat(video.format)
                )
                  continue;
                useBrowserStore.getState().addVideo({
                  id: video.url,
                  tabId: tab.id,
                  url: video.url,
                  title: typeof video.title === 'string' ? video.title.slice(0, 200) : tab.title,
                  format: video.format,
                  quality: typeof video.quality === 'string' ? video.quality : 'Auto',
                  sizeEstimate: 'Unknown',
                  detectedAt: Date.now(),
                });
              }
          } catch {
            /* Ignore messages not belonging to the browser bridge. */
          }
        }}
      />
      {loading && !error ? (
        <View pointerEvents="none" style={{ position: 'absolute', top: 16, alignSelf: 'center' }}>
          <Spinner size="sm" />
        </View>
      ) : null}
      {error ? (
        <View className="bg-background absolute inset-0 items-center justify-center gap-4 px-8">
          <AlertCircle color={colors.muted} size={36} />
          <AppText className="text-xl" weight="semibold">
            This page couldn’t load
          </AppText>
          <AppText className="text-muted text-center">Check your connection and try again.</AppText>
          <Button
            onPress={() => {
              setError(false);
              view.current?.reload();
            }}
          >
            <Button.Label>Try again</Button.Label>
          </Button>
        </View>
      ) : null}
    </View>
  );
}
