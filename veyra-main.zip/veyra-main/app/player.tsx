import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View } from 'react-native';
import { useLocalSearchParams, useFocusEffect } from 'expo-router';
import {
  useVideoPlayer,
  VideoView,
  type VideoSource,
  type VideoContentFit,
  type VideoPlayer,
} from 'expo-video';
import { useEvent } from 'expo';
import { Button, Slider, Spinner } from 'heroui-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import {
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Maximize,
  Ratio,
  Video,
  AlertCircle,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { AppText } from '@/components/AppText';
import { IconButton } from '@/components/BrowserControls';
import { BrowserDialog } from '@/components/BrowserDialog';
import { SafeAreaView } from '@/components/ui/primitives/SafeAreaView';
import { colors } from '@/lib/theme';
import { goBackOrReplace } from '@/lib/navigation';
import { useBrowserStore, type DetectedVideo } from '@/lib/browser-store';
// Expo Video exposes imperative native setters, not immutable React state.
function setPlaybackRate(player: VideoPlayer, rate: number) {
  player.playbackRate = rate;
}
function setPlayerVolume(player: VideoPlayer, volume: number) {
  player.volume = volume;
}
function seekTo(player: VideoPlayer, seconds: number) {
  player.currentTime = seconds;
}
const {
  Pan: panGesture,
  LongPress: longPressGesture,
  Tap: tapGesture,
  Race: raceGestures,
} = Gesture;
const exclusiveGestures = (...gestures: Parameters<typeof Gesture.Exclusive>) =>
  Gesture.Exclusive(...gestures);
const speeds = [0.5, 1, 1.25, 1.5, 2];
const fits: { title: string; fit: VideoContentFit }[] = [
  { title: 'Fit', fit: 'contain' },
  { title: 'Zoom', fit: 'cover' },
  { title: 'Stretch', fit: 'fill' },
];
function time(value: number) {
  const n = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
  return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;
}
export default function PlayerScreen() {
  const params = useLocalSearchParams<{
    url?: string;
    title?: string;
    format?: string;
    quality?: string;
    tabId?: string;
    referer?: string;
  }>();
  if (!params.url || !/^https?:\/\//i.test(params.url))
    return (
      <SafeAreaView className="bg-background flex-1 items-center justify-center gap-5 px-6">
        <Video size={40} color={colors.amber} />
        <AppText className="text-muted text-center">
          Choose a detected video to start watching.
        </AppText>
        <Button onPress={() => router.dismissTo('/browser')}>
          <Button.Label>Return to browser</Button.Label>
        </Button>
      </SafeAreaView>
    );
  return (
    <MediaPlayer
      url={params.url}
      title={params.title || 'Video'}
      format={params.format || 'mp4'}
      quality={params.quality || 'Auto'}
      tabId={params.tabId || ''}
      referer={params.referer || ''}
    />
  );
}
function MediaPlayer({
  url,
  title,
  format,
  quality,
  tabId,
  referer,
}: {
  url: string;
  title: string;
  format: string;
  quality: string;
  tabId: string;
  referer: string;
}) {
  const source: VideoSource = useMemo(
    () => ({
      uri: url,
      headers: referer ? { Referer: referer } : undefined,
      contentType: format === 'hls' ? 'hls' : format === 'dash' ? 'dash' : 'auto',
      useCaching: false,
    }),
    [url, referer, format],
  );
  const player = useVideoPlayer(source, (p) => {
    p.timeUpdateEventInterval = 0.25;
    p.play();
  });
  const { isPlaying } = useEvent(player, 'playingChange', { isPlaying: player.playing });
  const { status } = useEvent(player, 'statusChange', { status: player.status });
  const { currentTime } = useEvent(player, 'timeUpdate', {
    currentTime: player.currentTime,
    bufferedPosition: 0,
    currentLiveTimestamp: null,
    currentOffsetFromLive: null,
  });
  const [visible, setVisible] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [fit, setFit] = useState(0);
  const [qualityOpen, setQualityOpen] = useState(false);
  const [currentQuality, setCurrentQuality] = useState(quality);
  const [brightness, setBrightness] = useState(1);
  const [volume, setVolume] = useState(1);
  const [gestureLabel, setGestureLabel] = useState('');
  const [surfaceWidth, setSurfaceWidth] = useState(402);
  const [seek, setSeek] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const view = useRef<VideoView>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const feedbackTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = useRef({ volume: 1, brightness: 1 });
  const allVideos = useBrowserStore((s) => s.videos);
  const variants = allVideos[tabId] || [];
  const feedback = useCallback((message: string) => {
    setGestureLabel(message);
    if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
    feedbackTimer.current = setTimeout(() => setGestureLabel(''), 900);
  }, []);
  const show = useCallback(() => {
    setVisible(true);
    if (timer.current) clearTimeout(timer.current);
    if (player.playing) timer.current = setTimeout(() => setVisible(false), 3000);
  }, [player]);
  useEffect(() => {
    const subscription = player.addListener('playingChange', show);
    if (player.playing) timer.current = setTimeout(() => setVisible(false), 3000);
    return () => {
      subscription.remove();
      if (timer.current) clearTimeout(timer.current);
    };
  }, [player, show]);
  useEffect(
    () => () => {
      if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
    },
    [],
  );
  useEffect(() => {
    const subscription = player.addListener('statusChange', ({ status: nextStatus }) => {
      if (nextStatus === 'error') {
        setVisible(true);
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    });
    return () => subscription.remove();
  }, [player]);
  useFocusEffect(
    useCallback(
      () => () => {
        player.pause();
      },
      [player],
    ),
  );
  const changeSpeed = (next: number) => {
    setSpeed(next);
    setPlaybackRate(player, next);
    void Haptics.selectionAsync();
    show();
  };
  const onPanStart = useCallback(() => {
    start.current = { volume, brightness };
  }, [volume, brightness]);
  const onPanUpdate = useCallback(
    (e: { x: number; translationY: number }) => {
      if (e.x < surfaceWidth / 2) {
        const next = Math.max(0.15, Math.min(1, start.current.brightness - e.translationY / 250));
        setBrightness(next);
        feedback(`Brightness ${Math.round(next * 100)}%`);
      } else {
        const next = Math.max(0, Math.min(1, start.current.volume - e.translationY / 250));
        setPlayerVolume(player, next);
        setVolume(next);
        feedback(`Volume ${Math.round(next * 100)}%`);
      }
    },
    [surfaceWidth, player, feedback],
  );
  const onLongPressStart = useCallback(() => {
    setPlaybackRate(player, 2);
    feedback('2× speed');
  }, [player, feedback]);
  const onDoubleTapEnd = useCallback(
    (e: { x: number }) => {
      player.seekBy(e.x < surfaceWidth / 2 ? -10 : 10);
      feedback(e.x < surfaceWidth / 2 ? '−10 seconds' : '+10 seconds');
      show();
    },
    [player, surfaceWidth, feedback, show],
  );
  const onTapEnd = useCallback(() => {
    if (visible) setVisible(false);
    else show();
  }, [visible, show]);
  const gestures = raceGestures(
    // eslint-disable-next-line react/refs -- RNGH stores these callbacks; ref access occurs only during gesture events, not render.
    panGesture().minDistance(12).runOnJS(true).onStart(onPanStart).onUpdate(onPanUpdate),
    longPressGesture()
      .minDuration(400)
      .runOnJS(true)
      // eslint-disable-next-line react/refs -- RNGH registers this callback for a later long-press event.
      .onStart(onLongPressStart)
      .onFinalize(() => {
        setPlaybackRate(player, speed);
      }),
    exclusiveGestures(
      // eslint-disable-next-line react/refs -- RNGH registers this callback for a later double-tap event.
      tapGesture().numberOfTaps(2).runOnJS(true).onEnd(onDoubleTapEnd),
      // eslint-disable-next-line react/refs -- RNGH registers this callback for a later tap event.
      tapGesture().runOnJS(true).onEnd(onTapEnd),
    ),
  );
  const chooseVariant = async (video: DetectedVideo) => {
    setQualityOpen(false);
    setCurrentQuality(video.quality);
    const current = player.currentTime;
    try {
      await player.replaceAsync({
        uri: video.url,
        headers: referer ? { Referer: referer } : undefined,
        contentType: video.format === 'hls' ? 'hls' : video.format === 'dash' ? 'dash' : 'auto',
      });
      seekTo(player, current);
      setPlaybackRate(player, speed);
      player.play();
      void Haptics.selectionAsync();
    } catch {
      setErrorMessage('Couldn’t switch quality. Try the original stream.');
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    show();
  };
  const duration = Number.isFinite(player.duration) ? player.duration : 0;
  return (
    <SafeAreaView className="bg-background flex-1" edges={['top', 'bottom']}>
      <View className="flex-row items-center gap-3 px-3 py-3">
        <IconButton
          icon={ArrowLeft}
          label="Back to browser"
          onPress={() => goBackOrReplace('/browser')}
        />
        <AppText className="flex-1 text-base" weight="semibold" numberOfLines={2}>
          {title}
        </AppText>
        <Button
          variant="secondary"
          size="sm"
          onPress={() => {
            setQualityOpen(true);
            show();
          }}
        >
          <Button.Label>{currentQuality}</Button.Label>
        </Button>
      </View>
      <View
        style={{ flex: 1, backgroundColor: colors.black }}
        onLayout={(event) => setSurfaceWidth(event.nativeEvent.layout.width)}
      >
        <VideoView
          ref={view}
          style={{ width: '100%', height: '100%' }}
          player={player}
          contentFit={fits[fit].fit}
          nativeControls={false}
          fullscreenOptions={{ enable: true }}
          playsInline
        />
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: colors.black,
            opacity: 1 - brightness,
          }}
        />
        {/* eslint-disable-next-line react/refs -- GestureDetector receives a registered gesture object; it does not read React refs during render. */}
        <GestureDetector gesture={gestures}>
          <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        </GestureDetector>
        {gestureLabel ? (
          <View pointerEvents="none" className="absolute inset-0 items-center justify-center">
            <View className="bg-surface rounded-full px-5 py-3">
              <AppText weight="semibold">{gestureLabel}</AppText>
            </View>
          </View>
        ) : null}
        {status === 'loading' ? (
          <View pointerEvents="none" className="absolute inset-0 items-center justify-center">
            <Spinner />
          </View>
        ) : null}
        {status === 'error' || errorMessage ? (
          <View className="bg-background absolute inset-0 items-center justify-center gap-4 px-8">
            <AlertCircle size={36} color={colors.amber} />
            <AppText className="text-center text-lg" weight="semibold">
              This stream couldn’t play
            </AppText>
            <AppText className="text-muted text-center leading-6">
              {errorMessage ||
                'The link may have expired or require access from its original page.'}
            </AppText>
            <Button
              onPress={() => {
                setErrorMessage('');
                void player
                  .replaceAsync(source)
                  .then(() => player.play())
                  .catch(() => {
                    setErrorMessage(
                      'Couldn’t load this stream. Return to its page and try another link.',
                    );
                    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
                  });
              }}
            >
              <Button.Label>Try again</Button.Label>
            </Button>
          </View>
        ) : visible && status !== 'loading' ? (
          <View pointerEvents="box-none" className="absolute inset-0 items-center justify-center">
            <View className="flex-row items-center gap-8">
              <IconButton
                icon={RotateCcw}
                label="Rewind 10 seconds"
                onPress={() => {
                  player.seekBy(-10);
                  show();
                }}
              />
              <Button
                isIconOnly
                className="h-16 w-16 rounded-full"
                onPress={() => {
                  if (isPlaying) player.pause();
                  else player.play();
                  show();
                }}
                accessibilityLabel={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? (
                  <Pause color={colors.foreground} size={30} />
                ) : (
                  <Play color={colors.foreground} size={30} />
                )}
              </Button>
              <IconButton
                icon={RotateCw}
                label="Forward 10 seconds"
                onPress={() => {
                  player.seekBy(10);
                  show();
                }}
              />
            </View>
          </View>
        ) : null}
      </View>
      {visible ? (
        <View className="gap-4 px-5 py-5">
          <View className="flex-row items-center gap-3">
            <AppText className="text-muted text-xs">{time(seek ?? currentTime)}</AppText>
            <Slider
              className="flex-1"
              minValue={0}
              maxValue={Math.max(1, duration)}
              value={Math.max(0, Math.min(duration, seek ?? currentTime))}
              onChange={(value) => {
                if (typeof value !== 'number') return;
                setSeek(value);
                show();
              }}
              onChangeEnd={(value) => {
                if (typeof value !== 'number') return;
                seekTo(player, value);
                setSeek(null);
                show();
              }}
              isDisabled={duration <= 0}
              accessibilityLabel="Playback timeline"
            >
              <Slider.Track>
                <Slider.Fill />
                <Slider.Thumb />
              </Slider.Track>
            </Slider>
            <AppText className="text-muted text-xs">
              {player.isLive ? 'Live' : time(duration)}
            </AppText>
          </View>
          <View className="flex-row items-center justify-between">
            <Button
              variant="secondary"
              size="sm"
              onPress={() => changeSpeed(speeds[(speeds.indexOf(speed) + 1) % speeds.length])}
            >
              <Button.Label>{speed}×</Button.Label>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onPress={() => {
                setFit((fit + 1) % fits.length);
                void Haptics.selectionAsync();
                show();
              }}
            >
              <Ratio color={colors.foreground} size={20} />
              <Button.Label>{fits[fit].title}</Button.Label>
            </Button>
            <IconButton
              icon={Maximize}
              label="Fullscreen"
              onPress={() => {
                void view.current?.enterFullscreen().catch(() => {
                  setErrorMessage('Fullscreen is unavailable. You can keep watching here.');
                  void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
                });
              }}
            />
          </View>
        </View>
      ) : (
        <View className="h-5" />
      )}
      <BrowserDialog open={qualityOpen} onClose={() => setQualityOpen(false)} title="Video quality">
        <View className="gap-2">
          {variants.length ? (
            variants.map((video) => (
              <Button
                key={video.id}
                variant={video.quality === currentQuality ? 'primary' : 'secondary'}
                onPress={() => {
                  void chooseVariant(video);
                }}
              >
                <Button.Label numberOfLines={1}>
                  {video.quality} · {video.format.toUpperCase()}
                </Button.Label>
              </Button>
            ))
          ) : (
            <AppText className="text-muted">This stream uses automatic quality.</AppText>
          )}
        </View>
      </BrowserDialog>
    </SafeAreaView>
  );
}
