import { useEffect, useRef, useState } from 'react';
import { View, Platform, BackHandler } from 'react-native';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { Button, PressableFeedback } from 'heroui-native';
import {
  ArrowLeft,
  ArrowRight,
  Home,
  MoreVertical,
  RotateCw,
  X,
  Lock,
  ShieldAlert,
  Monitor,
  Video,
  Search,
  ChevronUp,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useCallback } from 'react';
import { SafeAreaView } from '@/components/ui/primitives/SafeAreaView';
import { AppText } from '@/components/AppText';
import { IconButton, TabsButton } from '@/components/BrowserControls';
import { BrowserSurface } from '@/components/BrowserSurface';
import type { BrowserHandle } from '@/components/BrowserSurface.types';
import { FloatingVideoBadge } from '@/components/FloatingVideoBadge';
import { VideoInspector } from '@/components/VideoInspector';
import { BrowserMenu } from '@/components/BrowserMenu';
import { useBrowserStore, domain } from '@/lib/browser-store';
import { colors } from '@/lib/theme';
const emptyVideos: never[] = [];
const goHome = () => router.dismissTo('/');
export default function BrowserScreen() {
  const params = useLocalSearchParams<{ url?: string }>();
  const tabs = useBrowserStore((s) => s.tabs);
  const activeId = useBrowserStore((s) => s.activeId);
  const hydrated = useBrowserStore((s) => s.hydrated);
  const desktop = useBrowserStore((s) => s.desktop);
  const videos = useBrowserStore((s) => s.videos[activeId] || emptyVideos);
  const activeTab = tabs.find((t) => t.id === activeId);
  const [state, setState] = useState({ canGoBack: false, canGoForward: false, loading: false });
  const [progress, setProgress] = useState(0);
  const [hidden, setHidden] = useState(false);
  const [inspector, setInspector] = useState(false);
  const [menu, setMenu] = useState(false);
  const [dimensions, setDimensions] = useState({ width: 402, height: 600 });
  const refs = useRef<Record<string, BrowserHandle | null>>({});
  const suppliedUrl = useRef('');
  useEffect(() => {
    if (
      hydrated &&
      params.url &&
      params.url !== suppliedUrl.current &&
      /^https?:\/\//i.test(params.url)
    ) {
      suppliedUrl.current = params.url;
      useBrowserStore.getState().navigate(params.url);
    }
  }, [params.url, hydrated]);
  const [previousActiveId, setPreviousActiveId] = useState(activeId);
  if (previousActiveId !== activeId) {
    setPreviousActiveId(activeId);
    setState({ canGoBack: false, canGoForward: false, loading: false });
    setHidden(false);
    setProgress(1);
  }
  useFocusEffect(
    useCallback(() => {
      setHidden(false);
      return undefined;
    }, [setHidden]),
  );
  const navigationHistory = useBrowserStore((s) => s.navigationHistory);
  const history = navigationHistory[activeId];
  const canGoBack = state.canGoBack || (history && history.index > 0);
  const canGoForward = state.canGoForward || (history && history.index < history.urls.length - 1);
  useFocusEffect(
    useCallback(() => {
      if (Platform.OS !== 'android') return undefined;
      const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
        if (inspector) {
          setInspector(false);
          return true;
        }
        if (state.canGoBack) {
          refs.current[activeId]?.back();
          return true;
        }
        const store = useBrowserStore.getState();
        const h = store.navigationHistory[store.activeId];
        if (h && h.index > 0) {
          store.moveHistory(-1);
          return true;
        }
        return false;
      });
      return () => subscription.remove();
    }, [inspector, state.canGoBack, activeId, setInspector]),
  );
  const handle = () => refs.current[activeId];
  const toggleDesktop = () => {
    useBrowserStore.getState().setDesktop(!desktop);
    void Haptics.selectionAsync();
  };
  return (
    <SafeAreaView className="bg-background flex-1" edges={['top', 'bottom']}>
      {!hidden ? (
        <View className="flex-row items-center gap-2 px-3 py-2">
          <PressableFeedback
            onPress={() =>
              router.push({ pathname: '/search', params: { query: activeTab?.url || '' } })
            }
            className="border-border bg-surface flex-1 flex-row items-center gap-2 rounded-full border px-4 py-3.5"
            accessibilityLabel="Edit web address"
            accessibilityRole="button"
          >
            {activeTab?.url.startsWith('https:') ? (
              <Lock size={16} color={colors.link} />
            ) : (
              <ShieldAlert size={16} color={colors.amber} />
            )}
            <AppText className="flex-1 text-sm" numberOfLines={1}>
              {activeTab?.isPrivate ? 'Private · ' : ''}
              {activeTab?.url ? domain(activeTab.url) : 'Search or enter address'}
            </AppText>
          </PressableFeedback>
          <IconButton
            icon={state.loading ? X : RotateCw}
            label={state.loading ? 'Stop loading' : 'Reload page'}
            onPress={() => (state.loading ? handle()?.stop() : handle()?.reload())}
          />
          <IconButton
            icon={Monitor}
            label={desktop ? 'Use mobile site' : 'Use desktop site'}
            onPress={toggleDesktop}
          />
        </View>
      ) : null}
      {state.loading && progress < 1 ? (
        <View style={{ height: 2, backgroundColor: colors.surface }}>
          <View
            style={{
              height: 2,
              backgroundColor: colors.link,
              width: `${Math.max(5, progress * 100)}%`,
            }}
          />
        </View>
      ) : null}
      <View
        style={{ flex: 1 }}
        onLayout={(event) =>
          setDimensions({
            width: event.nativeEvent.layout.width,
            height: event.nativeEvent.layout.height,
          })
        }
      >
        {tabs
          .filter((t) => t.url)
          .map((tab) => (
            <BrowserSurface
              key={tab.id}
              ref={(value) => {
                refs.current[tab.id] = value;
              }}
              tab={tab}
              active={tab.id === activeId}
              desktop={desktop}
              onState={setState}
              onProgress={setProgress}
              onScroll={setHidden}
            />
          ))}
        {!activeTab?.url ? (
          <View className="flex-1 items-center justify-center gap-4">
            <Search size={32} color={colors.muted} />
            <AppText className="text-muted">Where would you like to go?</AppText>
            <Button onPress={() => router.push('/search')}>
              <Button.Label>Search the web</Button.Label>
            </Button>
          </View>
        ) : Platform.OS !== 'web' ? (
          <FloatingVideoBadge
            count={videos.length}
            width={dimensions.width}
            height={dimensions.height}
            onPress={() => setInspector(true)}
          />
        ) : null}
      </View>
      {hidden ? (
        <View className="items-center">
          <IconButton
            icon={ChevronUp}
            label="Show browser controls"
            onPress={() => setHidden(false)}
          />
        </View>
      ) : (
        <View className="border-border bg-surface flex-row items-center justify-between border-t px-3 py-2">
          <IconButton
            icon={ArrowLeft}
            label="Previous page"
            disabled={!canGoBack || Platform.OS === 'web'}
            onPress={() => {
              if (state.canGoBack) handle()?.back();
              else useBrowserStore.getState().moveHistory(-1);
            }}
          />
          <IconButton
            icon={ArrowRight}
            label="Next page"
            disabled={!canGoForward || Platform.OS === 'web'}
            onPress={() => {
              if (state.canGoForward) handle()?.forward();
              else useBrowserStore.getState().moveHistory(1);
            }}
          />
          <TabsButton />
          <IconButton icon={Video} label="Detected videos" onPress={() => setInspector(true)} />
          <IconButton icon={Home} label="Home" onPress={goHome} />
          <IconButton icon={MoreVertical} label="Browser menu" onPress={() => setMenu(true)} />
        </View>
      )}
      <VideoInspector
        open={inspector}
        onClose={() => setInspector(false)}
        tabId={activeId}
        onRescan={() => handle()?.reload()}
      />
      <BrowserMenu open={menu} onClose={() => setMenu(false)} />
    </SafeAreaView>
  );
}
