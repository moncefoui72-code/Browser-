import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { colors } from '@/lib/theme';
export default function HomeLayout() {
  return (
    <>
      {/* eslint-disable-next-line react/style-prop-object -- Expo StatusBar style accepts a string enum, not a View style. */}
      <StatusBar style="light" />
      <Stack
        screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}
      />
    </>
  );
}
