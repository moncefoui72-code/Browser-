import { useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { Button, PressableFeedback, Skeleton } from 'heroui-native';
import {
  ShieldCheck,
  Mic,
  Scan,
  Plus,
  History,
  MoreVertical,
  ChevronRight,
  EyeOff,
  Search,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { SafeAreaView } from '@/components/ui/primitives/SafeAreaView';
import { AppText } from '@/components/AppText';
import { GoogleMark, MoncefLogo, SiteIcon } from '@/components/Brand';
import { IconButton, TabsButton } from '@/components/BrowserControls';
import { BrowserMenu } from '@/components/BrowserMenu';
import { BrowserDialog } from '@/components/BrowserDialog';
import { useBrowserStore, shortcuts, domain } from '@/lib/browser-store';
import { colors } from '@/lib/theme';

const open = (url: string) => {
  useBrowserStore.getState().navigate(url);
  router.push('/browser');
};
export default function HomeScreen() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const storedVisits = useBrowserStore((s) => s.visits);
  const tabs = useBrowserStore((s) => s.tabs);
  const activeId = useBrowserStore((s) => s.activeId);
  const hydrated = useBrowserStore((s) => s.hydrated);
  const isPrivate = tabs.find((t) => t.id === activeId)?.isPrivate;
  const visits = isPrivate ? [] : storedVisits;
  const { width } = useWindowDimensions();
  const newTab = () => {
    useBrowserStore.getState().addTab(!!isPrivate);
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.push('/search');
  };
  const recommendations = shortcuts.filter((s) => ['youtube', 'wikipedia'].includes(s.id));
  return (
    <SafeAreaView className="bg-background flex-1" edges={['top']}>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        <View
          className="items-center"
          style={{ paddingTop: width < 360 ? 32 : 50, paddingBottom: 28 }}
        >
          <MoncefLogo size={52} />
          <AppText
            weight="bold"
            style={{ fontSize: width < 360 ? 27 : 31, marginTop: 20, letterSpacing: -1.2 }}
          >
            Moncef{' '}
            <AppText
              weight="bold"
              style={{ fontSize: width < 360 ? 27 : 31, color: colors.googleBlue }}
            >
              Browser
            </AppText>
          </AppText>
          <View className="border-border bg-surface mt-5 flex-row items-center gap-2 rounded-full border px-4 py-2.5">
            {isPrivate ? (
              <EyeOff size={17} color={colors.link} />
            ) : (
              <ShieldCheck size={17} color={colors.link} />
            )}
            <AppText className="text-sm" style={{ color: colors.link }} weight="medium">
              {isPrivate ? 'Private browsing' : 'Your privacy matters'}
            </AppText>
          </View>
        </View>
        <PressableFeedback
          onPress={() => router.push('/search')}
          accessibilityRole="button"
          accessibilityLabel="Search or enter a web address"
          className="border-border bg-surface flex-row items-center gap-3 rounded-full border px-4 py-5"
        >
          <GoogleMark size={28} />
          <AppText
            className="text-muted flex-1"
            style={{ fontSize: width < 360 ? 13 : 15 }}
            numberOfLines={1}
          >
            Search or type web address...
          </AppText>
          <Mic size={20} color={colors.foreground} />
          <Scan size={20} color={colors.foreground} />
        </PressableFeedback>
        <View className="mt-6 gap-3">
          {[shortcuts.slice(0, 4), shortcuts.slice(4)].map((row) => (
            <View key={row.map((shortcut) => shortcut.id).join('-')} className="flex-row gap-3">
              {row.map((shortcut) => (
                <PressableFeedback
                  key={shortcut.id}
                  onPress={() => open(shortcut.url)}
                  accessibilityRole="button"
                  accessibilityLabel={`Open ${shortcut.title}`}
                  className="border-border bg-surface flex-1 items-center rounded-3xl border py-3.5"
                >
                  <SiteIcon name={shortcut.id} size={width < 360 ? 34 : 40} />
                  <AppText
                    className="mt-2.5"
                    style={{ fontSize: width < 360 ? 11 : 12 }}
                    numberOfLines={1}
                    weight="medium"
                  >
                    {shortcut.title}
                  </AppText>
                </PressableFeedback>
              ))}
            </View>
          ))}
        </View>
        <View className="mt-10 mb-5 flex-row items-center justify-between">
          <AppText className="text-xl" weight="semibold">
            {visits.length ? 'Frequently visited' : 'Recommended'}
          </AppText>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setHistoryOpen(true)}
            className="gap-0 px-0"
          >
            <Button.Label className="text-sm" style={{ color: colors.link }}>
              View all
            </Button.Label>
            <ChevronRight size={18} color={colors.link} />
          </Button>
        </View>
        {!hydrated ? (
          <Skeleton className="h-20 rounded-2xl" />
        ) : visits.length ? (
          visits.slice(0, 3).map((visit) => (
            <PressableFeedback
              key={visit.url}
              onPress={() => open(visit.url)}
              className="border-border bg-surface mb-3 flex-row items-center gap-4 rounded-2xl border p-4"
            >
              <SiteIcon
                name={shortcuts.find((s) => domain(s.url) === domain(visit.url))?.id || 'site'}
                size={44}
              />
              <View className="flex-1">
                <AppText weight="semibold" numberOfLines={1}>
                  {visit.title}
                </AppText>
                <AppText className="text-muted mt-1 text-sm" numberOfLines={1}>
                  {domain(visit.url)}
                </AppText>
              </View>
              <ChevronRight size={22} color={colors.muted} />
            </PressableFeedback>
          ))
        ) : (
          recommendations.map((site) => (
            <PressableFeedback
              key={site.id}
              onPress={() => open(site.url)}
              className="border-border bg-surface mb-3 flex-row items-center gap-4 rounded-2xl border p-4"
            >
              <SiteIcon name={site.id} size={44} />
              <View className="flex-1">
                <AppText className="text-lg" weight="semibold">
                  {site.title}
                </AppText>
                <AppText className="text-muted mt-1 text-sm">{domain(site.url)}</AppText>
              </View>
              <ChevronRight size={22} color={colors.muted} />
            </PressableFeedback>
          ))
        )}
      </ScrollView>
      <View className="border-border bg-surface pb-safe-or-3 rounded-t-3xl border-t px-7 pt-3">
        <View className="flex-row items-center justify-between">
          <TabsButton />
          <Button
            isIconOnly
            onPress={newTab}
            accessibilityLabel="New tab"
            className="h-14 w-14 rounded-full"
          >
            <Plus color={colors.foreground} size={30} strokeWidth={1.9} />
          </Button>
          <IconButton
            icon={History}
            onPress={() => setHistoryOpen(true)}
            label="Browsing history"
          />
          <IconButton icon={MoreVertical} onPress={() => setMenuOpen(true)} label="Browser menu" />
        </View>
      </View>
      <BrowserMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      <BrowserDialog open={historyOpen} onClose={() => setHistoryOpen(false)} title="Visited pages">
        <View className="gap-3">
          {visits.length ? (
            visits.map((visit) => (
              <Button
                key={visit.url}
                variant="ghost"
                className="h-auto justify-start py-3"
                onPress={() => {
                  setHistoryOpen(false);
                  open(visit.url);
                }}
              >
                <History size={18} color={colors.muted} />
                <View className="flex-1">
                  <AppText numberOfLines={1}>{visit.title}</AppText>
                  <AppText className="text-muted text-sm" numberOfLines={1}>
                    {domain(visit.url)}
                  </AppText>
                </View>
              </Button>
            ))
          ) : (
            <View className="items-center gap-4 py-8">
              <History size={32} color={colors.muted} />
              <AppText className="text-muted text-center">
                Pages you visit will appear here.
              </AppText>
              <Button
                onPress={() => {
                  setHistoryOpen(false);
                  router.push('/search');
                }}
              >
                <Search size={18} color={colors.foreground} />
                <Button.Label>Browse the web</Button.Label>
              </Button>
            </View>
          )}
        </View>
      </BrowserDialog>
    </SafeAreaView>
  );
}
