import { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View, FlatList } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Button, Input } from 'heroui-native';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Search,
  X,
  History,
  EyeOff,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { AppText } from '@/components/AppText';
import { GoogleMark } from '@/components/Brand';
import { IconButton } from '@/components/BrowserControls';
import { SafeAreaView } from '@/components/ui/primitives/SafeAreaView';
import { useBrowserStore, engines, resolveInput } from '@/lib/browser-store';
import { colors } from '@/lib/theme';
import { goBackOrReplace } from '@/lib/navigation';
export default function SearchScreen() {
  const params = useLocalSearchParams<{ query?: string }>();
  const [query, setQuery] = useState(params.query || '');
  const engine = useBrowserStore((s) => s.engine);
  const history = useBrowserStore((s) => s.history);
  const tabs = useBrowserStore((s) => s.tabs);
  const activeId = useBrowserStore((s) => s.activeId);
  const isPrivate = tabs.find((t) => t.id === activeId)?.isPrivate;
  const suggestions = useMemo(() => {
    const q = query.trim();
    if (!q) return [];
    return Array.from(
      new Set([
        q,
        ...(isPrivate ? [] : history)
          .filter((h) => h.query.toLowerCase().startsWith(q.toLowerCase()))
          .map((h) => h.query),
        `${q} browser`,
        `${q} privacy`,
        `${q} video`,
      ]),
    ).slice(0, 6);
  }, [query, history, isPrivate]);
  const submit = (value = query) => {
    if (!value.trim()) return;
    useBrowserStore.getState().addSearch(value.trim());
    useBrowserStore.getState().navigate(resolveInput(value, engine));
    router.dismissTo('/browser');
  };
  return (
    <SafeAreaView className="bg-background flex-1" edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View className="flex-row items-center gap-1 px-3 pt-3">
          <IconButton icon={ArrowLeft} onPress={() => goBackOrReplace('/')} label="Back" />
          <View
            className="border-border bg-surface flex-1 flex-row items-center gap-2 rounded-full border px-3"
            style={{ minWidth: 0 }}
          >
            {engine === 'Google' ? (
              <GoogleMark size={25} />
            ) : (
              <View className="bg-accent h-7 w-7 items-center justify-center rounded-full">
                <AppText weight="bold" className="text-sm">
                  {engine.charAt(0)}
                </AppText>
              </View>
            )}
            <Input
              autoFocus
              value={query}
              onChangeText={setQuery}
              onSubmitEditing={() => submit()}
              returnKeyType="search"
              autoCapitalize="none"
              autoCorrect={false}
              accessibilityLabel="Search or web address"
              placeholder="Search or enter address"
              background={null}
              style={{
                flex: 1,
                flexBasis: 0,
                width: 0,
                minWidth: 0,
                height: 52,
                backgroundColor: 'transparent',
                borderWidth: 0,
                outlineWidth: 0,
                paddingHorizontal: 0,
                fontFamily: 'Inter_400Regular',
                color: colors.foreground,
              }}
              className="flex-1 border-0 bg-transparent px-0 text-base"
            />
            {query ? (
              <Button
                isIconOnly
                variant="ghost"
                size="sm"
                onPress={() => setQuery('')}
                accessibilityLabel="Clear search"
              >
                <X color={colors.muted} size={18} />
              </Button>
            ) : null}
          </View>
          <IconButton
            icon={ArrowRight}
            primary
            onPress={() => submit()}
            label="Search"
            disabled={!query.trim()}
          />
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ flexGrow: 0 }}
          contentContainerStyle={{ gap: 8, paddingHorizontal: 20, paddingVertical: 22 }}
        >
          {engines.map((item) => (
            <Button
              key={item}
              variant={engine === item ? 'primary' : 'outline'}
              size="sm"
              className="rounded-full"
              onPress={() => {
                if (engine !== item) {
                  useBrowserStore.getState().setEngine(item);
                  void Haptics.selectionAsync();
                }
              }}
            >
              <Button.Label numberOfLines={1}>{item}</Button.Label>
            </Button>
          ))}
        </ScrollView>
        {isPrivate ? (
          <View className="mb-3 flex-row items-center gap-2 px-5">
            <EyeOff size={16} color={colors.link} />
            <AppText className="text-link text-sm">Private searches aren’t saved</AppText>
          </View>
        ) : null}
        {query.trim() ? (
          <>
            <AppText className="mt-2 mb-4 px-5 text-xl" weight="semibold">
              Suggestions
            </AppText>
            <FlatList
              data={suggestions}
              keyboardShouldPersistTaps="handled"
              keyExtractor={(item) => item}
              contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
              renderItem={({ item, index }) => (
                <View
                  className={`border-border bg-surface flex-row items-center px-3 ${index === 0 ? 'rounded-t-2xl' : 'border-t'} ${index === suggestions.length - 1 ? 'rounded-b-2xl' : ''}`}
                >
                  <Button
                    variant="ghost"
                    onPress={() => submit(item)}
                    className="h-16 flex-1 justify-start px-1"
                  >
                    <Search color={colors.muted} size={20} />
                    <Button.Label numberOfLines={1} className="flex-1 text-left">
                      {item}
                    </Button.Label>
                  </Button>
                  <IconButton
                    icon={ArrowUpRight}
                    onPress={() => setQuery(item)}
                    label={`Use ${item}`}
                  />
                </View>
              )}
            />
          </>
        ) : (
          <>
            <View className="mb-3 flex-row items-center justify-between px-5">
              <AppText className="text-xl" weight="semibold">
                Recent searches
              </AppText>
              {history.length && !isPrivate ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onPress={() => {
                    useBrowserStore.getState().removeSearch();
                    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  }}
                >
                  <Button.Label className="text-link">Clear all</Button.Label>
                </Button>
              ) : null}
            </View>
            <FlatList
              data={isPrivate ? [] : history}
              keyboardShouldPersistTaps="handled"
              keyExtractor={(item) => item.id}
              contentContainerStyle={{ paddingHorizontal: 20, flexGrow: 1 }}
              ListEmptyComponent={
                <View className="items-center gap-4 pt-16">
                  <Search color={colors.muted} size={32} />
                  <AppText className="text-muted">Your next search starts here.</AppText>
                  <Button variant="secondary" onPress={() => setQuery('privacy-first browsers')}>
                    <Button.Label>Try a search</Button.Label>
                  </Button>
                </View>
              }
              renderItem={({ item }) => (
                <Animated.View
                  entering={FadeIn}
                  exiting={FadeOut}
                  className="border-border flex-row items-center border-b"
                >
                  <Button
                    variant="ghost"
                    onPress={() => submit(item.query)}
                    className="h-20 flex-1 justify-start px-0"
                  >
                    <History size={20} color={colors.muted} />
                    <View className="flex-1">
                      <AppText numberOfLines={1}>{item.query}</AppText>
                      <AppText className="text-muted mt-1 text-xs">
                        {item.engine} ·{' '}
                        {new Date(item.timestamp).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </AppText>
                    </View>
                  </Button>
                  <IconButton
                    icon={X}
                    onPress={() => {
                      useBrowserStore.getState().removeSearch(item.id);
                      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                    }}
                    label={`Remove ${item.query}`}
                  />
                </Animated.View>
              )}
            />
          </>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
