import { useState } from 'react';
import { FlatList, View } from 'react-native';
import { Button, PressableFeedback } from 'heroui-native';
import { router } from 'expo-router';
import { Plus, X, EyeOff, Globe, Layers } from 'lucide-react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { AppText } from '@/components/AppText';
import { MoncefLogo } from '@/components/Brand';
import { BrowserDialog } from '@/components/BrowserDialog';
import { IconButton } from '@/components/BrowserControls';
import { SafeAreaView } from '@/components/ui/primitives/SafeAreaView';
import { useBrowserStore, domain } from '@/lib/browser-store';
import { colors } from '@/lib/theme';
function select(tabId: string) {
  useBrowserStore.getState().selectTab(tabId);
  const tab = useBrowserStore.getState().tabs.find((t) => t.id === tabId);
  router.dismissTo(tab?.url ? '/browser' : '/');
}
export default function TabsScreen() {
  const tabs = useBrowserStore((s) => s.tabs);
  const activeId = useBrowserStore((s) => s.activeId);
  const [isPrivate, setPrivate] = useState(!!tabs.find((t) => t.id === activeId)?.isPrivate);
  const [confirm, setConfirm] = useState(false);
  const shown = tabs.filter((t) => t.isPrivate === isPrivate);
  const add = () => {
    useBrowserStore.getState().addTab(isPrivate);
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.dismissTo('/');
  };
  return (
    <SafeAreaView edges={['bottom']} className="bg-background flex-1">
      <View className="flex-row gap-2 px-5 pt-4">
        {[false, true].map((value) => (
          <Button
            key={String(value)}
            className="flex-1 rounded-full"
            variant={isPrivate === value ? 'primary' : 'secondary'}
            onPress={() => {
              if (isPrivate !== value) {
                setPrivate(value);
                void Haptics.selectionAsync();
              }
            }}
          >
            {value ? <EyeOff size={17} color={colors.foreground} /> : null}
            <Button.Label numberOfLines={1}>
              {value ? 'Private' : 'Normal'} ({tabs.filter((t) => t.isPrivate === value).length})
            </Button.Label>
          </Button>
        ))}
      </View>
      <View className="flex-row items-center justify-between px-5 py-3">
        <AppText className="text-muted text-sm">
          {shown.length} {shown.length === 1 ? 'tab' : 'tabs'}
        </AppText>
        <Button
          variant="ghost"
          size="sm"
          isDisabled={!shown.length}
          onPress={() => setConfirm(true)}
        >
          <Button.Label className="text-link">Close all</Button.Label>
        </Button>
      </View>
      <FlatList
        data={shown}
        numColumns={2}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24, flexGrow: 1 }}
        columnWrapperStyle={{ gap: 12 }}
        ListEmptyComponent={
          <View className="flex-1 items-center justify-center gap-4 py-20">
            {isPrivate ? (
              <EyeOff size={34} color={colors.muted} />
            ) : (
              <Layers size={34} color={colors.muted} />
            )}
            <AppText className="text-muted">
              {isPrivate ? 'Private tabs appear here.' : 'Open a page to get started.'}
            </AppText>
            <Button onPress={add}>
              <Button.Label>New {isPrivate ? 'private ' : ''}tab</Button.Label>
            </Button>
          </View>
        }
        renderItem={({ item }) => (
          <Animated.View
            entering={FadeIn}
            exiting={FadeOut}
            style={{ flex: 1, maxWidth: '50%', marginBottom: 16 }}
          >
            <View
              className={`bg-surface rounded-2xl border-2 ${item.id === activeId ? 'border-accent' : 'border-border'}`}
            >
              <View className="flex-row items-center px-2 py-1">
                <Globe size={15} color={colors.link} />
                <AppText className="ml-2 flex-1 text-xs" numberOfLines={1} weight="medium">
                  {item.title}
                </AppText>
                <IconButton
                  icon={X}
                  onPress={() => {
                    useBrowserStore.getState().closeTab(item.id);
                    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  }}
                  label={`Close ${item.title}`}
                />
              </View>
              <PressableFeedback
                onPress={() => select(item.id)}
                accessibilityRole="button"
                accessibilityLabel={`Switch to ${item.title}`}
                className="px-3 pb-4"
              >
                <View className="bg-background h-28 items-center justify-center rounded-xl">
                  {item.isPrivate ? (
                    <EyeOff size={38} color={colors.muted} />
                  ) : item.url ? (
                    <Globe size={38} color={colors.link} strokeWidth={1.4} />
                  ) : (
                    <MoncefLogo size={40} />
                  )}
                </View>
                <AppText className="mt-3 text-sm" numberOfLines={2} weight="medium">
                  {item.title}
                </AppText>
                {item.url ? (
                  <AppText className="text-muted mt-1 text-xs" numberOfLines={1}>
                    {domain(item.url)}
                  </AppText>
                ) : null}
              </PressableFeedback>
            </View>
          </Animated.View>
        )}
      />
      <View className="border-border bg-background flex-row gap-3 border-t px-5 py-4">
        <Button className="flex-1" onPress={add}>
          <Plus size={18} color={colors.foreground} />
          <Button.Label>New tab</Button.Label>
        </Button>
        <Button variant="secondary" onPress={() => select(activeId)}>
          <Button.Label>Done</Button.Label>
        </Button>
      </View>
      <BrowserDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        title={`Close all ${isPrivate ? 'private ' : ''}tabs?`}
        footer={
          <Button
            variant="danger"
            onPress={() => {
              useBrowserStore.getState().closeAll(isPrivate);
              setConfirm(false);
              void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }}
          >
            <Button.Label>Close all</Button.Label>
          </Button>
        }
      >
        <AppText className="text-muted">
          {isPrivate
            ? 'Private tab details and detected videos will be removed.'
            : 'These open pages will be closed.'}
        </AppText>
      </BrowserDialog>
    </SafeAreaView>
  );
}
